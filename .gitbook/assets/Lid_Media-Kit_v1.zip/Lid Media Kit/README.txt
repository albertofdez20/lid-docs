LID · MEDIA KIT
lid.pro · docs.lid.pro/company/media-kit · 30 September 2026

Folders in this ZIP
-------------------
logos/        Logo for dark and light backgrounds, the mark and avatars (SVG and PNG)
colors/       The six brand colors (PNG sheet and CSS)
screenshots/  Real screens from lid.pro, captured 30 September 2026
banners/      Banners in five sizes, English (en) and Spanish (es)

Fonts: All Round Gothic and Nadea are licensed to Lid and not included. Stand-ins: Space Grotesk and Inter (Google Fonts).

LID
===

Lid. The creator suite.

Everything you need to write about Lid or feature us: descriptions you can paste, key facts, logos, colors, fonts, product screenshots and banners for events. Use them as they are.

Press contact
-------------

Alberto Fernández, co-founder and CEO. Email [alberto@lid.pro](mailto:alberto@lid.pro). We reply in English and Spanish.

ABOUT LID
=========

Copy any of these as they are. They are written in the third person.

One line
--------

English: Lid. The creator suite.

Español: Lid. La suite del creador.

About 25 words
--------------

English:
Lid is the creator suite. Creators sell their work, run challenges and campaigns, and get paid the moment someone buys, for a flat 3% per sale.

Español:
Lid es la suite del creador. Los creadores venden su trabajo, lanzan retos y campañas, y cobran en cuanto alguien compra. Pagan un 3% fijo por venta.

About 60 words
--------------

English:
Lid is the creator suite: store, challenges, campaigns, share links and memberships in one place. Creators sell what they make and get paid the moment someone buys. They pay a flat 3% per sale and nothing a month. Anyone can share their link and earn a cut the creator sets. Businesses run challenges and campaigns and pay for results.

Español:
Lid es la suite del creador: tienda, retos, campañas, enlaces para compartir y membresías en un solo lugar. Los creadores venden lo que hacen y cobran en cuanto alguien compra. Pagan un 3% fijo por venta y nada al mes. Quien comparte su enlace gana la parte que el creador decide. Los negocios pagan por resultados con retos y campañas.

About 120 words
---------------

English:
Lid is the creator suite. It puts everything a digital business needs to sell in one place: a store for files and courses, memberships, challenges with prizes, campaigns that pay for results, and share links anyone can use to earn a cut.

Selling online can mean five tools, up to 20% of each sale in fees and up to two months of waiting. On Lid, creators get paid the moment someone buys. Whoever shared the link has their cut saved, and only they can claim it. Nobody at Lid can hold a creator's money. Creators pay a flat 3% per sale and nothing a month. Lid's first three challenges assigned $300 in nine prizes, and every prize has been claimed.

Español:
Lid es la suite del creador. Reúne todo lo que un negocio digital necesita para vender: una tienda para archivos y cursos, membresías, retos con premios, campañas que pagan por resultados y enlaces para compartir con los que cualquiera gana una parte.

Vender en línea puede implicar cinco herramientas, hasta un 20% en comisiones y hasta dos meses de espera. En Lid, se cobra en cuanto alguien compra. Quien compartió el enlace tiene su parte guardada, y solo esa persona puede cobrarla. Nadie en Lid puede retener el dinero del creador. Los creadores pagan un 3% fijo por venta y nada al mes. Los tres primeros retos de Lid asignaron 300 USD en nueve premios, y todos ya se cobraron.

Key facts
---------

English:

Name: Lid, with a capital L
What it is: The creator suite: store, challenges, campaigns, share links and memberships in one place
Who it is for: Businesses with an audience, like schools, communities and agencies, and the creators around them
Live today: Store, memberships, challenges, campaigns and share links. AI agents can also create products and read data on Lid
Price: Creators pay a flat 3% per sale and nothing a month
Payments: Buyers pay in digital dollars (USDC). The creator receives them the moment someone buys
Proof: Lid's first three challenges assigned $300 in nine prizes, and every prize has been claimed. Anyone can check the record on lid.pro
Built on: Solana. Lid started on Solana in Colosseum's Frontier hackathon and was built at La Familia's El Taller in Madrid
Company: Lid Labs Technologies, registered in Dubai
Team: Madrid, Spain, and Colombia
Founders: Alberto Fernández, CEO, and Darwin Ramírez, CTO
Website: lid.pro
Docs: docs.lid.pro
On X: @Lid_onchain
Press contact: alberto@lid.pro

Español:

Nombre: Lid, con L mayúscula
Qué es: La suite del creador: tienda, retos, campañas, enlaces para compartir y membresías en un solo lugar
Para quién es: Negocios con audiencia, como escuelas, comunidades y agencias, y los creadores a su alrededor
Ya funciona: Tienda, membresías, retos, campañas y enlaces para compartir. Los agentes de IA también pueden crear productos y consultar datos en Lid
Precio: Los creadores pagan un 3% fijo por venta y nada al mes
Pagos: Los compradores pagan en dólares digitales (USDC). El creador los recibe en el momento en que alguien compra
Prueba: Los tres primeros retos de Lid asignaron 300 USD en nueve premios, y todos ya se cobraron. Cualquiera puede comprobarlo en lid.pro
Funciona sobre: Solana. Lid llegó a Solana en el hackathon Frontier de Colosseum y se construyó en El Taller de La Familia, en Madrid
Empresa: Lid Labs Technologies, registrada en Dubái
Equipo: Madrid, España, y Colombia
Fundadores: Alberto Fernández, CEO, y Darwin Ramírez, CTO
Sitio web: lid.pro
Documentación: docs.lid.pro
En X: @Lid_onchain
Contacto de prensa: alberto@lid.pro

Facts checked on 30 September 2026.

How to write about Lid
----------------------

- Lid, with a capital L.
- Lid is the creator suite.
- A sharer is anyone who shares a creator's link and earns a cut of the sale.
- Creators pay a flat 3% per sale and nothing a month.

LOGO AND BRAND
==============

Logo
----

The full logo for dark and light backgrounds, and the mark alone for small or square spaces.

File  ·  Use it on  ·  Formats
lid-logo-on-dark  ·  Dark backgrounds: white wordmark  ·  SVG, PNG
lid-logo-on-light  ·  Light backgrounds: navy wordmark  ·  SVG, PNG
lid-mark  ·  Small or square spaces  ·  SVG, PNG
lid-avatar-navy, lid-avatar-dark  ·  Profile pictures and app icons  ·  PNG, 1024 × 1024

All files are in the ZIP and the Google Drive folder on the Media kit page.

Rules
-----

- Use the files as they are. Never redraw, stretch, rotate or recolor them.
- The mark is always Medium Purple.
- The wordmark is white on dark backgrounds and navy on light ones. Never black.
- Keep the logo at least 55 px wide on screen.
- Leave at least 40 px of empty space between the Lid logo and any other logo.
- Place it on a plain background, never on a busy photo.

What not to do:

Colors
------

The six brand colors, with the values for screen and print.

Color  ·  HEX  ·  RGB  ·  CMYK  ·  Use
Medium Purple  ·  #A576FF  ·  165, 118, 255  ·  35, 54, 0, 0  ·  The Lid purple, from the mark
Navy Purple  ·  #211742  ·  33, 23, 66  ·  50, 65, 0, 74  ·  Panels, and the wordmark on light
Pure White  ·  #FFFFFF  ·  255, 255, 255  ·  0, 0, 0, 0  ·  Type and the wordmark on dark
Elderberry  ·  #100A20  ·  16, 10, 32  ·  50, 69, 0, 87  ·  The dark background
Pale Lavender  ·  #D9C5FF  ·  217, 197, 255  ·  15, 23, 0, 0  ·  Soft accents
Base Black  ·  #2C2C2D  ·  44, 44, 45  ·  2, 2, 0, 82  ·  Neutral panels only

Lid is dark first: most surfaces use Elderberry or Navy Purple, white type and one touch of Medium Purple. Text on Medium Purple is Elderberry, never white.

Fonts
-----

Font  ·  Use  ·  Get it
All Round Gothic  ·  Headlines  ·  Licensed to Lid, so the files are not included. [Space Grotesk](https://fonts.google.com/specimen/Space+Grotesk) (free on Google Fonts) is the stand-in
Nadea  ·  Body text  ·  Licensed to Lid, so the files are not included. [Inter](https://fonts.google.com/specimen/Inter) (free on Google Fonts) is the stand-in
JetBrains Mono  ·  Code and receipt IDs only  ·  Free at [jetbrains.com/lp/mono](https://www.jetbrains.com/lp/mono/)

PRODUCT SCREENSHOTS
===================

Every image is a real screen from lid.pro, captured on 30 September 2026 in a logged-out browser, the way a visitor sees it.

1. screenshots/lid-creator-page-desktop.png · Creator page. A creator's page on Lid, the one link a creator shares.
2. screenshots/lid-product-page-desktop.png · Product page. The buyer pays in digital dollars and gets instant access and a receipt. Anyone can share the product and earn the cut the creator set.
3. screenshots/lid-membership-desktop.png · Memberships. A monthly or yearly plan for members-only posts.
4. screenshots/lid-challenge-desktop.png · Challenge. A finished challenge: a $100 prize pool, assigned to three people who each claimed their prize.
5. screenshots/lid-product-page-mobile.png · On a phone. The same product page on a phone.
6. screenshots/lid-creator-page-mobile.png · On a phone. The creator page on a phone.

EVENTS AND PARTNERS
===================

Listing blurb
-------------

English:

Lid. The creator suite.

Store, challenges and campaigns in one place.

Español:

Lid. La suite del creador.

Tienda, retos y campañas en un solo lugar.

Banners
-------

Banners in five sizes, in English and Spanish. They are in the ZIP and the Google Drive folder on the Media kit page.

Size  ·  Use  ·  English  ·  Español
1500 × 500  ·  X header, web header  ·  lid-banner-en-1500x500.png  ·  lid-banner-es-1500x500.png
1200 × 627  ·  LinkedIn post, link preview  ·  lid-banner-en-1200x627.png  ·  lid-banner-es-1200x627.png
1080 × 1080  ·  Square post  ·  lid-banner-en-1080x1080.png  ·  lid-banner-es-1080x1080.png
1080 × 1920  ·  Story  ·  lid-banner-en-1080x1920.png  ·  lid-banner-es-1080x1920.png
1920 × 1080  ·  Slide or screen  ·  lid-banner-en-1920x1080.png  ·  lid-banner-es-1920x1080.png

On your own page, use the logo that matches your background, white wordmark on dark and navy on light, and link it to lid.pro.
